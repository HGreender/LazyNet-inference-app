import optuna
import torch
import gc
import os

from fast_ml_tools import LazyNet
from fast_ml_tools.lazy.lazy import MODEL_FACTORIES, LOSS_FACTORIES
from fast_ml_tools.ml.augmentations import get_imagenet_encoder_augmentation


class LazyNetOptuna:
    def __init__(
            self,
            # --- Данные ---
            train_img_dirs: list[str],
            train_mask_dirs: list[str],
            mask_suffix: str | list[str] = "_mask",
            augmentation_fn: callable = get_imagenet_encoder_augmentation,

            # --- Общие настройки ---
            classes: list = ['target_class'],
            device_id: int = 0,
            num_workers: int = 0,
            epochs: int = 30,
            n_trials: int = 30,
            save_dir: str = './optuna_trials',
            use_checkpoints: bool | None = None,
            train_ratio: float = 0.8,
            train_val_seed: int = 42,

            # --- Настройки балансировки (по умолчанию включены) ---
            stratify_by_mask: bool = True,
            min_pixels_threshold: int = 10,
            positive_weight: float = 1.0,

            # --- Пространства поиска гиперпараметров (Search Spaces) ---
            models_space: list = [None],
            models_names_space: list = MODEL_FACTORIES,
            losses_space: list = LOSS_FACTORIES,
            lr_range: tuple = (5e-6, 5e-4),  # (min, max)
            wd_range: tuple = (1e-6, 1e-4),  # (min, max)
            batch_sizes: list = [8, 16, 32],
            lr_factor_range: tuple = (0.1, 0.5),  # (min, max)
            lr_patience_range: tuple = (5, 15),  # (min, max),
            early_stopping_threshold_range: tuple = (8, 12),

            # Если None, используется фиксированный positive_weight из __init__
            positive_weight_range: tuple | None = None,

            # Параметры для Optuna
            study_name: str = "lazynet_seg",
            direction: str = "minimize"
    ):
        self.train_img_dirs = train_img_dirs
        self.train_mask_dirs = train_mask_dirs
        self.mask_suffix = mask_suffix
        self.augmentation_fn = augmentation_fn
        self.classes = classes
        self.device_id = device_id
        self.num_workers = num_workers
        self.default_epochs = epochs
        self.n_trials = n_trials
        self.save_dir = save_dir
        self.use_checkpoints = use_checkpoints
        self.train_ratio = train_ratio
        self.train_val_seed = train_val_seed

        # Параметры балансировки
        self.stratify_by_mask = stratify_by_mask
        self.min_pixels_threshold = min_pixels_threshold
        self.positive_weight = positive_weight
        self.positive_weight_range = positive_weight_range

        # Сохраняем пространства поиска
        self.models_space = models_space
        self.models_names_space = models_names_space
        self.losses_space = losses_space
        self.lr_range = lr_range
        self.wd_range = wd_range
        self.batch_sizes = batch_sizes
        self.lr_factor_range = lr_factor_range
        self.lr_patience_range = lr_patience_range
        self.early_stopping_threshold_range = early_stopping_threshold_range

        self.study_name = study_name
        self.direction = direction
        self.storage = f"sqlite:///{os.path.join(self.save_dir, 'study.db')}"
        self.study = None

    def _objective(self, trial):
        """Внутренняя функция-объектив"""
        lazy_net = None
        try:
            # 1. Выбор из заданных списков
            model_name = trial.suggest_categorical('model_name', self.models_names_space)
            model = trial.suggest_categorical('model', self.models_space)
            loss_name = trial.suggest_categorical('loss', self.losses_space)
            batch_size = trial.suggest_categorical('batch_size', self.batch_sizes)

            # 2. Выбор из диапазонов (float/int)
            lr = trial.suggest_float('lr', self.lr_range[0], self.lr_range[1], log=True)
            weight_decay = trial.suggest_float('weight_decay', self.wd_range[0], self.wd_range[1], log=True)
            lr_factor = trial.suggest_float('lr_factor', self.lr_factor_range[0], self.lr_factor_range[1], step=0.1)
            lr_patience = trial.suggest_int('lr_patience', self.lr_patience_range[0], self.lr_patience_range[1])
            early_stopping_threshold = trial.suggest_int(
                'early_stopping_threshold',
                self.early_stopping_threshold_range[0],
                self.early_stopping_threshold_range[1]
            )
            current_pos_weight = self.positive_weight
            if self.positive_weight_range:
                current_pos_weight = trial.suggest_float(
                    'positive_weight',
                    self.positive_weight_range[0],
                    self.positive_weight_range[1],
                )

            lazy_net = LazyNet(
                model_name=model_name,
                model=model,
                loss_name=loss_name,
                train_img_dirs=self.train_img_dirs,
                train_mask_dirs=self.train_mask_dirs,
                augmentation_fn=self.augmentation_fn,
                mask_suffix=self.mask_suffix,
                train_ratio=self.train_ratio,
                train_val_seed=self.train_val_seed,
                early_stopping_threshold=early_stopping_threshold,
                epochs=self.default_epochs,
                batch_size=batch_size,
                lr=lr,
                weight_decay=weight_decay,
                lr_patience=lr_patience,
                lr_factor=lr_factor,
                verbose=False,
                device_id=self.device_id,
                num_workers=self.num_workers,
                classes=self.classes,
                metric_names=None,
                stratify_by_mask=self.stratify_by_mask,
                min_pixels_threshold=self.min_pixels_threshold,
                positive_weight=current_pos_weight
            )

            best_val_loss = lazy_net.fit_with_optuna(
                trial=trial,
                save_dir=self.save_dir,
                epochs=self.default_epochs,
                use_checkpoints=self.use_checkpoints
            )

            return best_val_loss

        finally:
            if lazy_net is not None:
                del lazy_net

            gc.collect()
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def run(
            self,
            study_name: str | None = None,
            direction: str = 'minimize',
            n_warmup_steps: int = 5,
            n_trials: int | None = None,
    ):
        """Запуск оптимизации"""
        os.makedirs(self.save_dir, exist_ok=True)

        final_study_name = study_name or self.study_name
        self.study = optuna.create_study(
            study_name=final_study_name,
            storage=self.storage,
            direction=direction,
            pruner=optuna.pruners.MedianPruner(n_warmup_steps=n_warmup_steps),
            load_if_exists=True,
        )

        completed = len(self.study.get_trials(states=[optuna.trial.TrialState.COMPLETE]))
        print(f"Study '{final_study_name}': {completed} completed trials loaded")

        self.study.optimize(
            self._objective,
            n_trials=n_trials or self.n_trials,
            catch=(ValueError, RuntimeError, torch.cuda.OutOfMemoryError)
        )

        print(f"✅ Оптимизация завершена! Лучший результат: {self.study.best_value:.4f}")
        return self.study

    def delete_study(self, study_name: str | None = None):
        """Удалить study из хранилища"""
        name = study_name or self.study_name
        try:
            optuna.delete_study(study_name=name, storage=self.storage)
            self.study = None
            print(f"🗑️ Study '{name}' удалён")
        except KeyError:
            print(f"⚠️ Study '{name}' не найден")

    def list_studies(self):
        """Отобразить все studies в хранилище с их статистикой"""
        try:
            study_names = optuna.get_all_study_names(storage=self.storage)
        except Exception as e:
            print(f"❌ Не удалось прочитать хранилище: {e}")
            return []

        if not study_names:
            print("📭 В хранилище нет studies")
            return []

        print(
            f"\n{'Study Name':<25} {'Direction':<10} {'Complete':>8} {'Running':>7} {'Pruned':>6} {'Fail':>4} {'Total':>5} {'Best Value':>12}")
        print("─" * 95)

        studies_info = []
        for name in sorted(study_names):
            try:
                study = optuna.load_study(study_name=name, storage=self.storage)
            except Exception:
                continue

            trials = study.get_trials(deepcopy=False)
            states = {s: 0 for s in optuna.trial.TrialState}
            for t in trials:
                states[t.state] += 1

            best_val = None
            complete_trials = [t for t in trials if t.state == optuna.trial.TrialState.COMPLETE]
            if complete_trials:
                best_trial = min(complete_trials, key=lambda t: t.value) \
                    if study.direction == optuna.study.StudyDirection.MINIMIZE \
                    else max(complete_trials, key=lambda t: t.value)
                best_val = f"{best_trial.value:.4f}"
            else:
                best_val = "—"

            direction_str = "min" if study.direction == optuna.study.StudyDirection.MINIMIZE else "max"

            info = {
                "name": name,
                "direction": direction_str,
                "complete": states[optuna.trial.TrialState.COMPLETE],
                "running": states[optuna.trial.TrialState.RUNNING],
                "pruned": states[optuna.trial.TrialState.PRUNED],
                "fail": states[optuna.trial.TrialState.FAIL],
                "total": len(trials),
                "best_value": best_val,
            }
            studies_info.append(info)

            print(
                f"{info['name']:<25} "
                f"{info['direction']:<10} "
                f"{info['complete']:>8} "
                f"{info['running']:>7} "
                f"{info['pruned']:>6} "
                f"{info['fail']:>4} "
                f"{info['total']:>5} "
                f"{info['best_value']:>12}"
            )

        print()
        return studies_info

    def get_best_params(self):
        if not self.study:
            raise RuntimeError("Сначала запустите метод run()")
        return self.study.best_params

    def plot_results(self):
        if not self.study:
            raise RuntimeError("Нет данных для визуализации")
        optuna.visualization.plot_optimization_history(self.study).show()
        optuna.visualization.plot_param_importances(self.study).show()
        optuna.visualization.plot_slice(self.study).show()
